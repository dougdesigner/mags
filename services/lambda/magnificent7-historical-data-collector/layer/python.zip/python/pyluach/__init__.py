"""A Python package for dealing with Hebrew (Jewish) calendar dates.
"""


__version__ = '2.2.0'
